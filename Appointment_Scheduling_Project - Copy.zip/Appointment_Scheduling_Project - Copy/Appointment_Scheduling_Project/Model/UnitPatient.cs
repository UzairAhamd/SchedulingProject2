﻿using System;

namespace Appointment_Scheduling_Project.Model
{
    public class UnitPatient
    {
        public int PatientID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Country { get; set; }
        public string PhoneNumber { get; set; }
    }
}
